# About google-data-analytics-cyclistic-case-study

This is the capstone project I selected to complete for my Google Data Analytics Professional Certificate. This project is focused on analyzing Cyclistic (fictional bike-share company) bike rides from July 2023 - July 2024 in the City of Chicago. This case study used R and LibreOffice Calc (spreadsheet software). Please refer to the full instructions and requirements for this project in ORIGINAL_Option-1_How-does-a-bike-shared-navigate-speedy-success.pdf.
